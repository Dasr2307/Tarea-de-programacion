﻿namespace tarea
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;
            while (!salir)
            {
                char respuesta;
                int opcion, a, b, c;
                double area, volumen;
                Console.WriteLine("\n _____menu______");
                Console.WriteLine("\n 1- calcular el area de un trapecio");
                Console.WriteLine("\n 2- volumen de una esfera");
                Console.WriteLine("\n 3- mayor de 2 numeros ");
                Console.WriteLine("\n 4- salir ");

                Console.Write("\n elige una opcinon: ");
                opcion = Convert.ToInt16(Console.ReadLine());
                if (opcion == 1)
                {
                    Console.Write("agrega la base menor: ");
                    a = Convert.ToInt32(Console.ReadLine());
                    Console.Write("agrega la base mayor: ");
                    b = Convert.ToInt32(Console.ReadLine());
                    Console.Write("agrega la altura: ");
                    c = Convert.ToInt32(Console.ReadLine());
                    area = ((a + b) + c) / 2;
                    Console.WriteLine("el area de un trapecio es de: {0}", area);
                }
                else if (opcion == 2)
                {
                    Console.Write("agrega el radio de la esfera: ");
                    a = Convert.ToInt32(Console.ReadLine());
                    volumen = (4.0 / 3.0) + Math.PI + Math.Pow(a, 3);
                    Console.WriteLine("el volumen de la esfera es : {0}", volumen);
                }
                else if (opcion == 3)
                {
                    Console.Write("agrega el primer numero: ");
                    a = Convert.ToInt16(Console.ReadLine());
                    Console.Write("agrega el segundo numero: ");
                    b = Convert.ToInt16(Console.ReadLine());
                    if (a < b)
                    {
                        Console.WriteLine("el numero mayor es : {0}", b);
                    }
                    else if (b < a)
                    {
                        Console.WriteLine("el numero mayor es : {0}", a);
                    }
                    else
                    {
                        Console.WriteLine("los numeros son iguales ");
                    }
                }
                else if (opcion == 4)
                {
                    salir = true;
                }

                Console.WriteLine("\n desea continuar con el programa s/n");
                respuesta = Convert.ToChar(Console.ReadLine());

                if (respuesta == 'n')
                {
                    return;
                }
                else if (respuesta != 's')
                {
                    //salir del programa
                }
                Console.Clear();
            }
            Console.ReadKey();

        }
    }
}
        
